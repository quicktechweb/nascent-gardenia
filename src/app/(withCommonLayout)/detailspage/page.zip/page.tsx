"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence, Variants, useScroll } from "framer-motion";
import { HiChevronLeft, HiChevronRight } from "react-icons/hi";
import axios from "axios";
import { useViewportScroll, useTransform,useSpring  } from "framer-motion";
import { FaRegCalendarAlt } from "react-icons/fa";
interface RoomLayout {
  onClick: () => void;
}

interface BasicInfo {
  bedType: string;
  size: string;
  capacity: number;
  numberOfRooms: number;
  bedSize: string;
  floorInformation: string;
  view: string;
  checkinOut: string;
  extraBed: string;
  connectingRoom: string;
}

interface Room {
  id: string;
  title: string;
  bgColor: string;
  description: string;
  carouselImages: string[];
  facilities: string[];
  floorPlanImage: string;
  basicInfo: BasicInfo;
}

interface ApiRoomData {
  _id: string;
  heroImage: string;
  roomsdata: Room[];
  __v: number;
}

interface ApiResponse {
  success: boolean;
  data: ApiRoomData[];
}

export default function RoomLayout({ onClick }: RoomLayout) {

  const staticData = [
    {
      heroImage: "https://i.ibb.co/WvJ4g5qJ/alps-classic-gallery02.jpg",
      roomsdata: [
        {
          id: "1764739591531",
          title: "Alps Wing  Premier Room",
          roomType: "r",
          bgColor: "#000000",
          description: "Elegant premier guestrooms with extra space and luxury amenities for a refined stayElegant premier guestrooms with extra space and luxury amenities for a refined stayElegant premier guestrooms with extra space and luxury amenities for a refined stay",
          carouselImages: [
            "https://i.ibb.co/WvJ4g5qJ/alps-classic-gallery02.jpg",
            "https://i.ibb.co/pBQJM96n/alps-classic-gallery01.jpg",
            "https://i.ibb.co/T9xK4fx/alps-classic-gallery05.jpg",
          ],
          facilities: ["e"],
          floorPlanImage: "https://i.ibb.co/cK09FrvL/gym2.jpg",
          roomAmenities: "e",
          basicInfo: {
            bedType: "ty",
            size: "yt",
            capacity: 6,
            numberOfRooms: 6,
            bedSize: "t",
            floorInformation: "r",
            view: "r",
            checkinOut: "rt",
            extraBed: "r",
            connectingRoom: "tr",
          },
        },
      ],
    },
    {
      heroImage:
        "https://i.ibb.co/VYGDp65y/1763868724866-Whats-App-Image-2025-11-20-at-3-57-04-PM-new.jpg",
      roomsdata: [
        {
          id: "1764739839100",
          title: "Alps Wing Classic Room",
          roomType: "dsdf55557777",
          bgColor: "#000000",
          description: "Elegant premier guestrooms with extra space and luxury amenities for a refined stayElegant premier guestrooms with extra space and luxury amenities for a refined stayElegant premier guestrooms with extra space and luxury amenities for a refined stay",
          carouselImages: [
            "https://i.ibb.co/T9xK4fx/alps-classic-gallery05.jpg",
            "https://i.ibb.co/35hWRTnw/alps-classic-gallery04.jpg",
            "https://i.ibb.co/WvJ4g5qJ/alps-classic-gallery02.jpg",
          ],
          facilities: ["ee"],
          floorPlanImage:
            "https://i.ibb.co/VYGDp65y/1763868724866-Whats-App-Image-2025-11-20-at-3-57-04-PM-new.jpg",
          roomAmenities: "e",
          basicInfo: {
            bedType: "44444444444",
            size: "e",
            capacity: 4,
            numberOfRooms: 4,
            bedSize: "4",
            floorInformation: "4",
            view: "4",
            checkinOut: "4",
            extraBed: "4",
            connectingRoom: "4",
          },
        },
      ],
    },
  ];
const allRooms: Room[] = staticData.flatMap((item) => item.roomsdata);

 const [roomsdata] = useState<Room[]>(allRooms);
  const [heroImage] = useState(staticData[0].heroImage);
const [showModal, setShowModal] = useState(false);

  const [isOpen, setIsOpen] = useState<number | null>(null);
  const [currentRoomIndex, setCurrentRoomIndex] = useState(0);
  const [currentSection, setCurrentSection] = useState<
    "initial" | "roomType" | "services"
  >("initial");
  

  const roomRefs = useRef<HTMLDivElement[]>([]);
  const carouselRefs = useRef<HTMLDivElement[]>([]);

   const [arrival, setArrival] = useState("");
  const [departure, setDeparture] = useState("");
  const [useSingleDate, setUseSingleDate] = useState(true);
  const [nights, setNights] = useState(1);
  const [rooms, setRooms] = useState(1);
  const [guests, setGuests] = useState(1);

 const handleSearch = () => {
  if (!arrival || (!useSingleDate && !departure)) {
    alert("Please select the required date(s)!");
    return; // stop execution if dates are missing
  }

  // const finalDeparture = useSingleDate
  //   ? new Date(new Date(arrival).getTime() + 24 * 60 * 60 * 1000)
  //       .toISOString()
  //       .split("T")[0]
  //   : departure;

  

  // window.location.href = `/vacancy?${query}`;
  window.location.href = `/selectroom`;
};
  const [windowWidth, setWindowWidth] = useState(0);

useEffect(() => {
  setWindowWidth(window.innerWidth); // only runs on client
}, []);
  // Fetch rooms from API
 

  const halfReveal: Variants = {
    hidden: { opacity: 0, y: 80, scale: 0.95, clipPath: "inset(40% 0% 0% 0%)", filter: "blur(6px)" },
    show: { opacity: 1, y: 0, scale: 1, clipPath: "inset(0% 0% 0% 0%)", filter: "blur(0px)", transition: { duration: 1.3, ease: [0.16, 1, 0.3, 1] } }
  };

  // Scroll marker effect
  useEffect(() => {
    const handleScroll = () => {
      let found = false;
      roomRefs.current.forEach((ref, index) => {
        if (!ref) return;
        const rect = ref.getBoundingClientRect();
        if (rect.top < window.innerHeight / 2 && rect.bottom > window.innerHeight / 2) {
          setCurrentRoomIndex(index);
          setCurrentSection("roomType");
          found = true;
        }
      });

      const services = document.getElementById("services");
      if (services) {
        const rect = services.getBoundingClientRect();
        if (rect.top < window.innerHeight / 2 && rect.bottom > 0) {
          setCurrentSection("services");
          found = true;
        }
      }

      if (!found) setCurrentSection("initial");
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const getRightBg = () => {
    switch (currentSection) {
      case "roomType":
        return "bg-[#e9e0d9] text-black";
      case "services":
        return " text-black";
      default:
        return "bg-[#e9e0d9] text-black";
    }
  };

  const scrollCarousel = (index: number, direction: "prev" | "next") => {
    const el = carouselRefs.current[index];
    if (!el) return;
    const scrollAmount = el.offsetWidth;
    el.scrollBy({ left: direction === "next" ? scrollAmount : -scrollAmount, behavior: "smooth" });
  };

  const { scrollY } = useScroll();

  // -----------------------------
  // CURTAIN ANIMATION (Left/Right)
  // -----------------------------
  const leftRaw = useTransform(scrollY, [0, 300], ["0%", "-100%"]);
  const rightRaw = useTransform(scrollY, [0, 300], ["0%", "100%"]);

  const leftCurtainX = useSpring(leftRaw, {
    stiffness: 70,
    damping: 18,
    mass: 0.25,
  });

  const rightCurtainX = useSpring(rightRaw, {
    stiffness: 70,
    damping: 18,
    mass: 0.25,
  });

  // --------------------------------------
  // IMAGE SMOOTH OPEN (FROM YOUR PROVIDED)
  // --------------------------------------
  const smoothHeight = useSpring(
  useTransform(scrollY, [0, 400], ["70vh", "80vh"]),
  { stiffness: 50, damping: 20 }
);


  const smoothScaleX = useSpring(
    useTransform(scrollY, [0, 400], [1.1, 1.4]),
    { stiffness: 50, damping: 20 }
  );

  const smoothX = useSpring(
    useTransform(scrollY, [0, 400], [0, -60]),
    { stiffness: 50, damping: 20 }
  );

  // const { scrollY } = useViewportScroll();

  // // Transformations for scroll animation
  // const scale = useTransform(scrollY, [0, 400], [1, 1.2]); // zoom in
  // const translateX = useTransform(scrollY, [0, 400], [0, -50]); // move left
  // const translateY = useTransform(scrollY, [0, 400], [0, -50]); 
  const [isScrolling, setIsScrolling] = useState(false);

  useEffect(() => {
    let timeout: ReturnType<typeof setTimeout> | null = null;

    const handleScroll = () => {
      setIsScrolling(true);

      if (timeout) clearTimeout(timeout);

      timeout = setTimeout(() => {
        setIsScrolling(false);
      }, 200);
    };

    window.addEventListener("scroll", handleScroll);

    return () => {
      window.removeEventListener("scroll", handleScroll);
      if (timeout) clearTimeout(timeout);
    };
  }, []);

  return (
    <div className={`w-full min-h-screen transition-colors  duration-700 ${getRightBg()}`}>
      <div className="flex relative w-full min-h-screen ">
        {/* Sidebar */}
   <div className="hidden md:flex w-1/5 max-w-3xl sticky top-0 self-start z-20">
    <div className="p-12 space-y-6 mt-40 text-sm  ">
      <h3 className="text-lg font-bold mb-6">Index</h3>
      <p className="font-semibold">Room Type</p>
      <div className="space-y-4">
        {roomsdata.map((room, i) => (
          <div
            key={room.id}
            className="flex cursor-pointer items-center"
            onClick={() => {
              roomRefs.current[i]?.scrollIntoView({ behavior: "smooth", block: "start" });
              setCurrentRoomIndex(i);
              setCurrentSection("roomType");
            }}
          >
            <p
              className={`px-2 py-1 rounded transition-colors duration-300 ${
                currentRoomIndex === i ? "bg-gray-800/20" : "hover:bg-gray-800/10"
              } text-lg opacity-60`}
            >
              - {room.title}
            </p>
          </div>
        ))}
      </div>
    </div>
  </div>

        {/* Main Content */}
        <div className="w-full md:w-4/5 md:-ml-[4%] relative px-2">
          {/* Hero Image */}
         <h1 style={{ fontFamily: '"Monrovia Modern Serif", serif' }} className="mt-40 text-8xl   font-normal">
                Rooms & Suites
              </h1>
              
      <div className="relative w-full flex justify-center items-center h-screen">
  {/* Hero Image */}
  <div className="absolute inset-0 w-full h-full overflow-hidden max-w-[1500px]">
    <Image
      src="https://www.mampei.co.jp/wp-content/themes/mampei/assets/img/rooms/fv.webp"
      alt="Hero"
      fill
      className="object-cover"
      style={{ objectPosition: "center" }}
      priority
    />
  </div>

  {/* Left curtain */}
  <motion.div
    style={{
      x: leftCurtainX, // only curtains move
      transform: "translateZ(0)",
    }}
    className="absolute top-0 left-0 w-[35%] h-full bg-[#e9e0d9]"
  />

  {/* Right curtain */}
  <motion.div
    style={{
      x: rightCurtainX, // only curtains move
      transform: "translateZ(0)",
    }}
    className="absolute top-0 right-0 w-[35%] h-full bg-[#e9e0d9]"
  />

  {/* Hero Text */}
  <motion.div
    className="absolute top-0 left-0 w-full h-full flex flex-col justify-center items-center text-white z-10 pointer-events-none"
    style={{
      y: useSpring(
        useTransform(scrollY, [0, 200], [50, 0]), // small fade/move for text only
        { stiffness: 50, damping: 20 }
      ),
      opacity: useSpring(
        useTransform(scrollY, [0, 150], [0, 1]),
        { stiffness: 50, damping: 20 }
      ),
    }}
  >
    <h1 className="text-5xl md:text-6xl font-bold text-center">
      NASCENT GARDENIA BARIDHARA
    </h1>
    <p className="text-lg md:text-2xl max-w-2xl text-center mt-4">
      Discover our premium rooms and services
    </p>
  </motion.div>
</div>





 

    {/* Rooms Section */}
    <div className="w-full px-4 transition-colors duration-700">
      {roomsdata.map((room, roomIndex) => (
        <div key={room.id} className="my-8" ref={(el) => { if (el) roomRefs.current[roomIndex] = el; }}>
          {/* Room content */}
        </div>
      ))}
    </div>

 {/* RESERVATION MODAL */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-20">
          <div className="bg-white p-6 rounded-xl max-w-md w-full relative">
            <button
              className="absolute top-3 right-3 text-xl font-bold"
              onClick={() => setShowModal(false)}
            >
              &times;
            </button>

            <h2 className="text-lg font-semibold mb-4">Book a Room</h2>

            {/* Date Mode Toggle */}
            <div className="mb-4 flex gap-2">
              <button
                className={`flex-1 py-2 rounded ${
                  useSingleDate ? "bg-black text-white" : "bg-gray-200"
                }`}
                onClick={() => setUseSingleDate(true)}
              >
                Single Date
              </button>
              <button
                className={`flex-1 py-2 rounded ${
                  !useSingleDate ? "bg-black text-white" : "bg-gray-200"
                }`}
                onClick={() => setUseSingleDate(false)}
              >
                Double Date
              </button>
            </div>

            {/* Arrival Date */}
            <div className="mb-4">
              <label className="block text-sm font-medium">Arrival Date</label>
              <input
                type="date"
                value={arrival}
                onChange={(e) => setArrival(e.target.value)}
                className="w-full border rounded px-3 py-2 mt-1"
              />
            </div>

            {/* Departure Date (only if double date) */}
            {!useSingleDate && (
              <div className="mb-4">
                <label className="block text-sm font-medium">Departure Date</label>
                <input
                  type="date"
                  value={departure}
                  onChange={(e) => setDeparture(e.target.value)}
                  className="w-full border rounded px-3 py-2 mt-1"
                />
              </div>
            )}

            {/* Nights, Rooms, Guests */}
            <div className="mb-4 flex gap-2">
              <div className="flex-1">
                <label className="block text-sm font-medium">Nights</label>
                <input
                  type="number"
                  min={1}
                  value={nights}
                  onChange={(e) => setNights(Number(e.target.value) || 1)}
                  className="w-full border rounded px-3 py-2 mt-1"
                />
              </div>
              <div className="flex-1">
                <label className="block text-sm font-medium">Rooms</label>
                <input
                  type="number"
                  min={1}
                  value={rooms}
                  onChange={(e) => setRooms(Number(e.target.value) || 1)}
                  className="w-full border rounded px-3 py-2 mt-1"
                />
              </div>
              <div className="flex-1">
                <label className="block text-sm font-medium">Guests</label>
                <input
                  type="number"
                  min={1}
                  value={guests}
                  onChange={(e) => setGuests(Number(e.target.value) || 1)}
                  className="w-full border rounded px-3 py-2 mt-1"
                />
              </div>
            </div>

            <button
              onClick={handleSearch}
              className="w-full bg-black text-white py-3 rounded-full font-semibold"
            >
              Search Vacancy
            </button>
          </div>
        </div>
      )}

          {/* Rooms Section */}
        <div className="w-full px-4 transition-colors duration-700">

       <div className="mt-20">
         <h2 className="font-serif text-6xl">Guestrooms</h2>
        <p className="text-md ms-12 mt-9">The Alps Wing, Atago Wing, and Usui Wing––our three guestroom wings––stand within the grounds of the hotel amid the refreshing breeze and surrounded by the lush woodlands of Karuizawa. We invite you to enjoy a moment of luxurious relaxation, pondering long-held traditions and the passage of time.</p>
       </div>
  {roomsdata.map((room, roomIndex) => (
    <div
      key={room.id}
      className="my-8 bg-[#e4d9d1] shadow-lg"
      ref={(el: HTMLDivElement | null) => {
        if (el) roomRefs.current[roomIndex] = el;
      }}
    >
      <div className="border-t mt-10 border-[#0f3333] border-8"></div>
     <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-8 gap-4 px-8 py-5">
  {/* Left: Title + Description */}
  <div className="flex-1">
    <h1 className="text-3xl md:text-4xl font-serif mb-4">{room.title}</h1>
    <p className="max-w-2xl">{room.description}</p>
  </div>

  {/* Right: Book Now Button */}
  <div className="flex-shrink-0">
    <button
      onClick={() => setShowModal(true)}
      className="px-8 py-3 bg-[#c78436] rounded-full text-black shadow-lg flex items-center gap-2 hover:bg-[#b37730] transition"
    >
      Book Now
    </button>
  </div>
</div>

      {/* Carousel */}
      <div className="relative overflow-hidden w-full mb-6 px-8 py-5">
        <button
          onClick={() => scrollCarousel(roomIndex, "prev")}
          className="absolute left-2 top-1/2 -translate-y-1/2 z-10 bg-white/80 hover:bg-white rounded-full p-3"
        >
          <HiChevronLeft className="text-2xl" />
        </button>
        <button
          onClick={() => scrollCarousel(roomIndex, "next")}
          className="absolute right-2 top-1/2 -translate-y-1/2 z-10 bg-white/80 hover:bg-white rounded-full p-3"
        >
          <HiChevronRight className="text-2xl" />
        </button>

        <motion.div
          className="flex gap-4 overflow-x-auto scrollbar-hide"
          ref={(el: HTMLDivElement | null) => {
            if (el) carouselRefs.current[roomIndex] = el;
          }}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.3 }}
          variants={{ hidden: {}, show: { transition: { staggerChildren: 0.2 } } }}
        >
          {room.carouselImages.map((src, i) => (
            <motion.div
              key={i}
              className="relative min-w-[300px] md:min-w-[670px] h-72 md:h-[600px] flex-shrink-0 overflow-hidden rounded-xl"
              variants={halfReveal} // your animation variant
            >
              <Image src={src} alt={`${room.title} image ${i + 1}`} fill className="object-cover" />
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* Accordion */}
      <div className="w-full   rounded-lg overflow-hidden px-8 py-5">
  {/* Header */}
  <div className="w-full flex justify-between items-center px-4 py-3">
    <span className="font-medium text-gray-700">Basic Information</span>
  </div>

  {/* Content always visible */}
  <div className=" text-gray-600">
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 px-4 py-3">
      <div className="space-y-1">
        {Object.entries(room.basicInfo).map(([key, value]) => (
          <p key={key}>
            <strong>{key}:</strong> {value}
          </p>
        ))}
      </div>
      <div className="space-y-1">
        <p>
          <strong>Room facilities & Amenities:</strong>
        </p>
        {room.facilities.map((f, i) => (
          <p key={i}>{f}</p>
        ))}
      </div>
    </div>

    {/* Optional floor plan */}
    {/* 
    <div className="w-full h-64 flex justify-center py-4 border-t">
      <Image
        src={room.floorPlanImage}
        alt={`${room.title} Floor Plan`}
        width={800}
        height={600}
        className="object-contain"
      />
    </div> 
    */}
  </div>
</div>

      
    </div>
    
  ))}
</div>


        </div>
      </div>
    </div>
  );
}
